<?php
$conn  = mysqli_connect("localhost","root","","otp");
?>