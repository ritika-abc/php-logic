 


<?php

//  s n 2

$conn  = mysqli_connect("localhost","u496524825_otpuser","Otpuser123456","u496524825_otp");

function generateOTP()
{
    $otp = rand(100000, 999999);
    return $otp;
}

// Send OTP via email
function sendOTP($email, $otp)
{
    $to = $email;
    $subject = "Your OTP for registration";
    $message = "Your OTP is: " . $otp;
    $headers = "From: ritikamaheshonly@gmail.com";

    // Send email
    mail($to, $subject, $message, $headers);
}



if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];

    // Generate and store OTP
    $otp = generateOTP();
    $_SESSION["otp"] = $otp;

    // Send OTP via email
    sendOTP($email, $otp);



    $sql = "SELECT  * from users  WHERE 
     name='$name' and email='$email'  ";

    $emailresult = mysqli_query($conn, $sql);

    $user_matched = mysqli_num_rows($emailresult);
    
    if ($user_matched > 0) {
        echo "you have already registered !!";
         $stored_otp = $_SESSION["otp"];
    } else {
        $insrt = mysqli_query($conn, "INSERT INTO 
        `users`(`name`, `email`,`otp`) VALUES
         ('$name','$email','$otp')");
 if ($conn->query($sql) === TRUE) {
        // Redirect to OTP verification page
      
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
        if ($insrt) {
            header("location:otp_verification.php");
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="" method="post" class=" w-75 m-auto mt-5">
        <label for=""> user name</label>
        <input type="text" class="form-control" name="name">


        <label for=""> password</label>
        <input type="email" class="form-control" name="email">


        <input type="submit" name="submit">
    </form>
</body>

</html>


</body>

</html>