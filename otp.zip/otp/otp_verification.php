<?php
session_start();

$conn  = mysqli_connect("localhost","u496524825_otpuser","Otpuser123456","u496524825_otp");


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if (isset($_POST['submit'])) {
    // Retrieve OTP entered by the user
    $entered_otp = $_POST["otp"];

    // Retrieve stored OTP from session
    $stored_otp = $_SESSION["otp"];

    // Check if entered OTP matches stored OTP
    if ($entered_otp == $stored_otp) {
        // OTP is correct
        echo "OTP verification successful. You can now proceed with registration.";
        // Here you can perform further actions like setting a flag in the database indicating OTP verification is successful, or redirecting the user to another page.
    } else {
        // OTP is incorrect
        echo "OTP verification failed. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
</head>
<body>
    <h2>OTP Verification</h2>
    <form method="post" action="">
        <label for="otp">Enter OTP:</label><br>
        <input type="text" id="otp" name="otp" required><br><br>
        <input type="submit" name="submit" value="Verify OTP">
    </form>
</body>
</html>
