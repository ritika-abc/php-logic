<?php
session_start();

// Database connection parameters
$conn  = mysqli_connect("localhost","u496524825_otpuser","Otpuser123456","u496524825_otp");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Generate OTP
function generateOTP() {
    $otp = rand(100000, 999999);
    return $otp;
}

// Send OTP via email
function sendOTP($email, $otp) {
    $to = $email;
    $subject = "Your OTP for registration";
    $message = "Your OTP is: " . $otp;
    $headers = "From: ritikamaheshonly@gmail.com";

    // Send email
    mail($to, $subject, $message, $headers);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];



 $sql = "SELECT  * from users  WHERE 
     name='$name' and email='$email'  ";

    $emailresult = mysqli_query($conn, $sql);

    $user_matched = mysqli_num_rows($emailresult);
 if ($user_matched > 0) {
        echo "you have already registered !!";
    } else {
         // Generate and store OTP
    $otp = generateOTP();
    $_SESSION["otp"] = $otp;

    // Send OTP via email
    sendOTP($email, $otp);

    // Insert user data into database
    $sql = "INSERT INTO users (name, email, phone, otp) VALUES ('$name', '$email', '$phone', '$otp')";
    if ($conn->query($sql) === TRUE) {
        // Redirect to OTP verification page
        header("Location: otp_verification.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    }


   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
</head>
<body>
    <h2>Registration Form</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name"><br><br>
        
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email"><br><br>
        
        <label for="phone">Phone:</label><br>
        <input type="text" id="phone" name="phone"><br><br>
        
        <input type="submit" value="Submit">
    </form>
</body>
</html>
